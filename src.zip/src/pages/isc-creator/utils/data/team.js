export const team = [
  {
    name: "Prof. Dr. Mohamed Amine Chatti",
    link: "https://www.uni-due.de/soco/people/mohamed-chatti.php",
    email: "mohamed.chatti@uni-due.de",
    img: "/img/soco-chatti.jpg",
  },
  {
    name: "M.Sc. Shoeb Joarder",
    link: "https://www.uni-due.de/soco/people/shoeb-joarder.php",
    email: "shoeb.joarder@uni-due.de",
    img: "/img/soco-shoeb.jpg",
  },
];
