const RoleTypes = {
  user: "ROLE_USER",
  userWithoutLRS: "ROLE_USER_WITHOUT_LRS",
  ["data provider"]: "ROLE_DATA_PROVIDER",
};

export default RoleTypes;
