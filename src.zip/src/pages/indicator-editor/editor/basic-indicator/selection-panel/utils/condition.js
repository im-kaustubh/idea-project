const Condition = {
  only_me: "ONLY_ME",
  exclude_me: "EXCLUDE_ME",
  all: "INCLUDE_ME",
};

export default Condition;
